#include "../src/pugixml.hpp"

#if PUGIXML_VERSION != 1140 // 1.14
#error Unexpected pugixml version
#endif
